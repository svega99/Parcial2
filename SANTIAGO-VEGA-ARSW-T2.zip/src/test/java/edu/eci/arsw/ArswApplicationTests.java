package edu.eci.arsw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


class ArswApplicationTests {

	@Test
	void contextLoads() {
	}

}
